import os
import warnings
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

warnings.filterwarnings("ignore")

os.makedirs("visualizations", exist_ok=True)
os.makedirs("screenshots", exist_ok=True)


df1 = pd.read_csv("data/Unemployment in India.csv")
df2 = pd.read_csv("data/Unemployment_Rate_upto_11_2020.csv")

print("=" * 60)
print("DATASET 1 INFORMATION")
print("=" * 60)

print("\nShape:")
print(df1.shape)

print("\nColumns:")
print(df1.columns.tolist())

print("\nData Types:")
print(df1.dtypes)

print("\nFirst 5 Rows:")
print(df1.head())

print("\nLast 5 Rows:")
print(df1.tail())

print("\nStatistics:")
print(df1.describe())

df1.columns = df1.columns.str.strip()
df2.columns = df2.columns.str.strip()

print("\nMissing Values:")
print(df1.isnull().sum())

df1.drop_duplicates(inplace=True)
df2.drop_duplicates(inplace=True)

df1.ffill(inplace=True)
df2.ffill(inplace=True)


df1["Date"] = pd.to_datetime(df1["Date"])
df2["Date"] = pd.to_datetime(df2["Date"])

df1["Year"] = df1["Date"].dt.year
df1["Month"] = df1["Date"].dt.month


rate_col = "Estimated Unemployment Rate (%)"


plt.figure(figsize=(10, 5))
sns.histplot(df1[rate_col], bins=20, kde=True)
plt.title("Distribution of Unemployment Rate")
plt.savefig("visualizations/histogram.png")
plt.close()


plt.figure(figsize=(8, 5))
sns.boxplot(x=df1[rate_col])
plt.title("Unemployment Rate Boxplot")
plt.savefig("visualizations/boxplot.png")
plt.close()


trend = df1.groupby("Date")[rate_col].mean()

plt.figure(figsize=(12, 6))
trend.plot()
plt.title("Unemployment Trend Over Time")
plt.ylabel("Unemployment Rate (%)")
plt.savefig("visualizations/unemployment_trend.png")
plt.close()


highest_states = (
    df1.groupby("Region")[rate_col]
    .mean()
    .sort_values(ascending=False)
    .head(10)
)

plt.figure(figsize=(10, 6))
highest_states.plot(kind="bar")
plt.title("Top 10 States with Highest Unemployment")
plt.ylabel("Average Rate")
plt.tight_layout()
plt.savefig("visualizations/highest_unemployment_states.png")
plt.close()


lowest_states = (
    df1.groupby("Region")[rate_col]
    .mean()
    .sort_values()
    .head(10)
)

plt.figure(figsize=(10, 6))
lowest_states.plot(kind="bar")
plt.title("Top 10 States with Lowest Unemployment")
plt.ylabel("Average Rate")
plt.tight_layout()
plt.savefig("visualizations/lowest_unemployment_states.png")
plt.close()


monthly = df1.groupby("Month")[rate_col].mean()

plt.figure(figsize=(10, 5))
monthly.plot(marker="o")
plt.title("Monthly Unemployment Trend")
plt.ylabel("Average Unemployment Rate")
plt.savefig("visualizations/monthly_trend.png")
plt.close()


yearly = df1.groupby("Year")[rate_col].mean()

plt.figure(figsize=(8, 5))
yearly.plot(kind="bar")
plt.title("Yearly Unemployment Trend")
plt.ylabel("Average Rate")
plt.savefig("visualizations/yearly_trend.png")
plt.close()


if "Area" in df1.columns:

    area_analysis = (
        df1.groupby("Area")[rate_col]
        .mean()
        .sort_values(ascending=False)
    )

    plt.figure(figsize=(7, 5))
    area_analysis.plot(kind="bar")
    plt.title("Urban vs Rural Unemployment")
    plt.ylabel("Average Rate")
    plt.savefig("visualizations/urban_rural_analysis.png")
    plt.close()


numeric_df = df1.select_dtypes(include=np.number)

plt.figure(figsize=(8, 6))
sns.heatmap(
    numeric_df.corr(),
    annot=True,
    cmap="coolwarm"
)
plt.title("Correlation Heatmap")
plt.savefig("visualizations/correlation_heatmap.png")
plt.close()


covid_df = df1.copy()

pre_covid = covid_df[covid_df["Date"] < "2020-03-01"]

during_covid = covid_df[
    (covid_df["Date"] >= "2020-03-01")
]

pre_avg = pre_covid[rate_col].mean()
during_avg = during_covid[rate_col].mean()

change_percent = (
    ((during_avg - pre_avg) / pre_avg)
    * 100
)

print("\n" + "=" * 60)
print("COVID IMPACT ANALYSIS")
print("=" * 60)

print(f"Average Before COVID : {pre_avg:.2f}")
print(f"Average During COVID : {during_avg:.2f}")
print(f"Percentage Change    : {change_percent:.2f}%")

covid_compare = pd.DataFrame({
    "Period": ["Pre-COVID", "COVID"],
    "Average Unemployment": [pre_avg, during_avg]
})

plt.figure(figsize=(8, 5))
sns.barplot(
    data=covid_compare,
    x="Period",
    y="Average Unemployment"
)
plt.title("COVID Impact on Unemployment")
plt.savefig("visualizations/covid_impact.png")
plt.close()


pre_state = (
    pre_covid.groupby("Region")[rate_col]
    .mean()
)

during_state = (
    during_covid.groupby("Region")[rate_col]
    .mean()
)

impact = (
    during_state - pre_state
).sort_values(ascending=False)

print("\nMost Affected States:")
print(impact.head(10))

print("\nLeast Affected States:")
print(impact.tail(10))

if "Region.1" in df2.columns:

    region_analysis = (
        df2.groupby("Region.1")
        ["Estimated Unemployment Rate (%)"]
        .mean()
        .sort_values(ascending=False)
    )

    plt.figure(figsize=(10, 5))
    region_analysis.plot(kind="bar")
    plt.title("Region Wise Unemployment")
    plt.ylabel("Average Rate")
    plt.tight_layout()
    plt.savefig("visualizations/region_analysis.png")
    plt.close()


