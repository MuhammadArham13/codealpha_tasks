# Unemployment Analysis with Python

## CodeAlpha Data Science Internship

### Project Overview

This project analyzes unemployment trends in India using Python. The objective is to understand unemployment patterns across different states and regions, investigate the impact of COVID-19, identify seasonal trends, and generate insights that can support economic and social policy decisions.

The project includes data cleaning, exploratory data analysis (EDA), visualization, COVID-19 impact analysis, trend analysis, and policy recommendations.

---

## Dataset Information

### Dataset 1: Unemployment in India.csv

Features:

* Region
* Date
* Frequency
* Estimated Unemployment Rate (%)
* Estimated Employed
* Estimated Labour Participation Rate (%)
* Area

### Dataset 2: Unemployment_Rate_upto_11_2020.csv

Additional Features:

* Region.1 (Geographical Region)
* longitude
* latitude

---

## Technologies Used

* Python
* Pandas
* NumPy
* Matplotlib
* Seaborn
* Scikit-Learn

---

## Project Workflow

1. Data Loading
2. Data Cleaning
3. Data Preprocessing
4. Exploratory Data Analysis
5. Data Visualization
6. COVID-19 Impact Analysis
7. Trend Analysis
8. Seasonal Analysis
9. Policy Recommendations
10. Final Reporting

---

## Visualizations Generated

* Unemployment Trend Over Time
* State-wise Unemployment Analysis
* Top States with Highest Unemployment
* Top States with Lowest Unemployment
* Correlation Heatmap
* Box Plot Analysis
* Histogram Distribution
* Monthly Trend Analysis
* Yearly Trend Analysis
* Region Comparison
* COVID-19 Impact Comparison

---

## Key Findings

* Significant rise in unemployment during COVID-19 lockdown periods.
* Certain states experienced higher unemployment spikes than others.
* Monthly unemployment trends indicate seasonal variations.
* Post-COVID recovery trends differ across regions.
* Urban areas showed stronger employment recovery compared to rural areas in several states.

---

## Installation

```bash
pip install -r requirements.txt
```

Run:

```bash
python unemployment_analysis.py
```

---

## Future Improvements

* Machine Learning Forecasting
* Interactive Dashboard using Streamlit
* Real-time Economic Data Integration
* State-wise Forecasting Models

---

## Author

Muhammad Arham

CodeAlpha Data Science Internship
