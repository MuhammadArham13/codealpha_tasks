import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pickle

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer

from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor

from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score


# =====================================
# LOAD DATASET
# =====================================

df = pd.read_csv("car data.csv")

print("=" * 50)
print("DATASET SHAPE")
print(df.shape)

print("\nFIRST 10 RECORDS")
print(df.head(10))

print("\nLAST 10 RECORDS")
print(df.tail(10))

print("\nCOLUMN NAMES")
print(df.columns)

print("\nDATA TYPES")
print(df.dtypes)

print("\nSTATISTICAL SUMMARY")
print(df.describe())


# =====================================
# DATA CLEANING
# =====================================

print("\nMISSING VALUES")
print(df.isnull().sum())

df.drop_duplicates(inplace=True)

print("\nAFTER DUPLICATE REMOVAL")
print(df.shape)


# =====================================
# FEATURE ENGINEERING
# =====================================

current_year = 2025

df["Car_Age"] = current_year - df["Year"]

df.drop("Year", axis=1, inplace=True)


# =====================================
# EDA
# =====================================

sns.set_style("whitegrid")

# Price Distribution

plt.figure(figsize=(8,5))
sns.histplot(df["Selling_Price"], kde=True)
plt.title("Price Distribution")
plt.savefig("price_distribution.png")
plt.show()


# Correlation Heatmap

numeric_df = df.select_dtypes(include=np.number)

plt.figure(figsize=(10,6))
sns.heatmap(numeric_df.corr(), annot=True, cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.savefig("correlation_heatmap.png")
plt.show()


# Fuel Type vs Price

plt.figure(figsize=(8,5))
sns.boxplot(x="Fuel_Type", y="Selling_Price", data=df)
plt.title("Fuel Type vs Selling Price")
plt.savefig("fuel_vs_price.png")
plt.show()


# Transmission vs Price

plt.figure(figsize=(8,5))
sns.boxplot(x="Transmission", y="Selling_Price", data=df)
plt.title("Transmission vs Price")
plt.savefig("transmission_vs_price.png")
plt.show()


# Mileage vs Price

plt.figure(figsize=(8,5))
sns.scatterplot(x="Driven_kms", y="Selling_Price", data=df)
plt.title("Mileage vs Price")
plt.savefig("mileage_vs_price.png")
plt.show()


# Brand Extraction

df["Brand"] = df["Car_Name"].apply(lambda x: x.split()[0])

brand_price = (
    df.groupby("Brand")["Selling_Price"]
    .mean()
    .sort_values(ascending=False)
    .head(10)
)

plt.figure(figsize=(12,6))
brand_price.plot(kind="bar")
plt.title("Top Brands by Average Price")
plt.ylabel("Average Selling Price")
plt.savefig("brand_price_comparison.png")
plt.show()


# =====================================
# PREPARE DATA
# =====================================

X = df.drop("Selling_Price", axis=1)
y = df["Selling_Price"]

categorical_features = X.select_dtypes(include="object").columns
numeric_features = X.select_dtypes(exclude="object").columns

numeric_transformer = Pipeline(
    steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ]
)

categorical_transformer = Pipeline(
    steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ]
)

preprocessor = ColumnTransformer(
    transformers=[
        ("num", numeric_transformer, numeric_features),
        ("cat", categorical_transformer, categorical_features)
    ]
)

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42
)


# =====================================
# MODELS
# =====================================

models = {
    "Linear Regression": LinearRegression(),
    "Decision Tree": DecisionTreeRegressor(random_state=42),
    "Random Forest": RandomForestRegressor(
        n_estimators=200,
        random_state=42
    ),
    "Gradient Boosting": GradientBoostingRegressor(
        random_state=42
    )
}

results = []

best_model = None
best_score = -999

for name, model in models.items():

    pipeline = Pipeline(
        steps=[
            ("preprocessor", preprocessor),
            ("model", model)
        ]
    )

    pipeline.fit(X_train, y_train)

    predictions = pipeline.predict(X_test)

    mae = mean_absolute_error(y_test, predictions)
    mse = mean_squared_error(y_test, predictions)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, predictions)

    results.append([name, mae, rmse, r2])

    if r2 > best_score:
        best_score = r2
        best_model = pipeline

print("\nMODEL COMPARISON")

results_df = pd.DataFrame(
    results,
    columns=["Model", "MAE", "RMSE", "R2"]
)

print(results_df.sort_values("R2", ascending=False))


# =====================================
# SAVE BEST MODEL
# =====================================

pickle.dump(
    best_model,
    open("best_car_price_model.pkl", "wb")
)

print("\nBest model saved successfully!")


# =====================================
# ACTUAL VS PREDICTED
# =====================================

predictions = best_model.predict(X_test)

plt.figure(figsize=(8,6))
plt.scatter(y_test, predictions)
plt.xlabel("Actual Price")
plt.ylabel("Predicted Price")
plt.title("Actual vs Predicted Price")
plt.savefig("actual_vs_predicted.png")
plt.show()


# =====================================
# CUSTOM PREDICTION
# =====================================

print("\nCUSTOM CAR PRICE PREDICTION")

brand = input("Car Name: ")
present_price = float(input("Present Price: "))
kms = int(input("Driven Kms: "))
fuel = input("Fuel Type: ")
selling_type = input("Selling Type: ")
transmission = input("Transmission: ")
owner = int(input("Owner Count: "))
year = int(input("Year: "))

car_age = 2025 - year

sample = pd.DataFrame({
    "Car_Name": [brand],
    "Present_Price": [present_price],
    "Driven_kms": [kms],
    "Fuel_Type": [fuel],
    "Selling_type": [selling_type],
    "Transmission": [transmission],
    "Owner": [owner],
    "Car_Age": [car_age]
})

price = best_model.predict(sample)

print("\nEstimated Selling Price:")
print(round(price[0], 2), "Lakhs")
